#Chart.Scatter

*Scatter chart plugin for Chart.js* [chartjs.org](http://www.chartjs.org)

[Documentation & live demo](http://dima117.github.io/Chart.Scatter/)

## License

Chart.Scatter.js is available under the [MIT license](http://opensource.org/licenses/MIT).

## Bugs & issues

When reporting bugs or issues, if you could include a link to a simple [jsbin](http://jsbin.com) or similar demonstrating the issue, that'd be really helpful.
